Run the file InstallClient.bat from this directory as administrator where TCS is installed. Use [or create] InstallIlluminate.bat and use [or create] InstallAdmin.bat.

If InstallAdmin.bat was used, then run the command below in an administrator PowerShell prompt:

	cd '\inetpub\TitusWebAdministration\CustomFunctions'
	gci . | Unblock-File

If InstallAdmin.bat was used, then run the command below in an administrator PowerShell prompt:

	cd '\Program Files\Titus\Titus Services\EnterpriseClientService\CustomFunctions\Content.Extensibility'
	gci . | Unblock-File


questions? email: titusextensions@helpsystems.com

thank you!

bill brunt

